Citizen.CreateThread(function()
	-- Nissan GTR
	AddTextEntry('0x9F05F101', 'gtr17')
	-- Range Rover
    AddTextEntry('', '')
    
    AddTextEntry('0x03279B2E', 'Lightweight_Forged_Aluminum_Wheel')

    
    AddTextEntry('0xF6023556', 'Hellcat_Front_Bumper')
    
   --[[  AddTextEntry('', '')
    
    AddTextEntry('', '')
    
    AddTextEntry('', '')
    
    AddTextEntry('', '') ]]
end)


--[[  = 

0x2FA98C6D = Custom Rear Bumper 1

0x3E75DF29 = SXT Front Bumper

0x4C347AA6 = R/T Front Bumper

0x4F1ECB57 = Custom Rear Bumper 2

0x5A1E1914 = Hellcat Side Skirts

0x5E6F69F8 = Custom Hellcat Rear Bumper 3

0x6E98C209 = Custom Hellcat Side Skirts

0x7B24D862 = SRT Rear Badge

0x19A19551 = Custom Hellcat Front Bumper

0x55FEAA91 = Black Painted Roof

0x76BE29FC = 2012 Dodge SRT Wheel

0x90C003A0 = R/T Rear Badge

0x94BFD698 = Custom Hellcat Rear Bumper 1

0x98B18FF9 = Fast & Furious Wheel

0x212CA72A = Custom Side Skirts

0x651C12CB = Performance Wing

0x89561DFB = 392 HEMI Side Badge

0xA6B85776 = Polished Aluminum Wheel With Black Pockets and Satin Finish

0xA6F6FB06 = Hellcat Rear Bumper

0xAF0F881E = SRT 392 Bonnet

0xB7C1B819 = Hellcat Spoiler

0xB78CFA68 = Hellcat Side Badge

0xBED0A7A0 = Hellcat Bonnet

0xC288B22D = Custom Hellcat Rear Bumper 2

0xCD285F36 = Polished Aluminum Wheel With Graphite Pockets

0xD444711E = Race Wing

0xD1008440 = R/T Road & Track Front Bumper

0xDDDF5C75 = Matte Black Lightweight Forged Aluminum Wheel

0xE0C623CB = R/T Scat Pack Front Bumper

0xE7BE9307 = Custom R/T Road & Track Front Bumper

0xEB2476FF = Brass Monkey Lightweight Forged Aluminum Wheel

0xF5C04DBF = SRT 392 Front Bumper

0xFAE5A474 = Charger '16

0xFC3882B4 = Dodge

 ]]